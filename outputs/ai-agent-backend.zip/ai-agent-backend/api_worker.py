"""Run the actual app.py workflow in an isolated job directory."""
import json
import os
from pathlib import Path
import sys

# app.py loads the project's .env before importing an engine.
from app import identify_card, research_card

def execute(kind, work):
    work = Path(work).resolve()
    payload = json.loads((work / "request.json").read_text(encoding="utf-8"))
    if kind == "ocr":
        return identify_card(work / "image.png")
    if kind == "research":
        return {"report": research_card(payload["lines"], payload["engine"], "card")}
    raise ValueError("Unknown job type")

def main():
    kind, work = sys.argv[1], Path(sys.argv[2]).resolve()
    os.chdir(work)
    (work / "results").mkdir(exist_ok=True)
    result = execute(kind, work)
    (work / "response.json").write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")

if __name__ == "__main__":
    main()

