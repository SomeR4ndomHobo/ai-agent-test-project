import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app
import api_worker

class WorkflowTests(unittest.TestCase):
    def test_engine_dispatch_and_aliases(self):
        lines = [{"text": "TEST LABEL", "confidence": .9}]
        for name in ["openai", "pydantic", "psydantic", "crewai", "langgraph", "langraph"]:
            selected = app.normalize_engine(name)
            module, function = app.ENGINES[selected]
            calls = []
            stub = types.SimpleNamespace(**{function: lambda *args: calls.append(args) or "A complete report"})
            with patch.dict(sys.modules, {module: stub}):
                self.assertEqual(app.research_card(lines, name, "C:\\cards\\card.jpg"), "A complete report")
            self.assertEqual(calls, [(lines, "card")])

    def test_worker_calls_shared_app_workflow(self):
        with tempfile.TemporaryDirectory() as temp:
            work = Path(temp)
            lines = [{"text": "TEST LABEL"}]
            (work / "request.json").write_text(json.dumps({"engine":"openai","lines":lines}))
            with patch.object(api_worker, "research_card", return_value="Live function result") as run:
                self.assertEqual(api_worker.execute("research", work), {"report":"Live function result"})
                run.assert_called_once_with(lines, "openai", "card")
            with patch.object(api_worker, "identify_card", return_value={"raw_ocr":lines}) as read:
                self.assertEqual(api_worker.execute("ocr", work), {"raw_ocr":lines})
                read.assert_called_once_with(work / "image.png")

    def test_empty_label_rejected_before_import(self):
        with patch.object(app.importlib, "import_module") as load:
            with self.assertRaises(ValueError):
                app.research_card([], "openai")
            load.assert_not_called()

    def test_empty_report_is_failure(self):
        module, function = app.ENGINES["openai"]
        with patch.dict(sys.modules, {module:types.SimpleNamespace(**{function:lambda *_: None})}):
            with self.assertRaises(RuntimeError):
                app.research_card([{"text":"Card"}])

    def test_invalid_engine_cli_reprompts(self):
        result = {"raw_ocr":[{"text":"Card","confidence":None}]}
        with patch("builtins.input", side_effect=["image.png","invalid","bye","bye"]) as prompt, patch.object(app,"identify_card",return_value=result), patch("builtins.print"):
            app.main()
            self.assertEqual(prompt.call_count, 4)

if __name__ == "__main__":
    unittest.main()

