"""Shared sports-card workflow for the command line and Card Lab website."""
import importlib
import json
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

ENGINES = {
    "openai": ("openai_multiagent", "run_agent_openai"),
    "pydantic": ("pydantic_multiagent", "run_agent_pydantic"),
    "crewai": ("crewai_multiagent", "run_agent_crewai"),
    "langgraph": ("langraph_multiagent", "run_agent_langraph"),
}
ALIASES = {"psydantic": "pydantic", "langraph": "langgraph"}

def normalize_engine(engine):
    value = str(engine).strip().lower()
    value = ALIASES.get(value, value)
    if value not in ENGINES:
        raise ValueError("Choose openai, pydantic, crewai, or langgraph.")
    return value

def identify_card(image_path):
    # Heavy OCR dependencies initialize only when a card is read.
    from ocr import identify_card as read
    Path("results").mkdir(parents=True, exist_ok=True)
    return read(str(Path(image_path).resolve()))

def print_ocr_results(card_result):
    for item in card_result["raw_ocr"]:
        confidence = item.get("confidence")
        suffix = f" {confidence:.2%}" if confidence is not None else ""
        print(f'{item["text"]}{suffix}')

def research_card(raw_ocr, engine="openai", card_filename="card"):
    selected = normalize_engine(engine)
    if not isinstance(raw_ocr, list) or not any(
        isinstance(line, dict) and str(line.get("text", "")).strip()
        for line in raw_ocr
    ):
        raise ValueError("Read a card label before starting research.")
    module, function = ENGINES[selected]
    # Use a safe basename because existing engines put this value in a results path.
    name = Path(str(card_filename).replace("\\", "/")).stem or "card"
    if name in {".", ".."}:
        name = "card"
    output = getattr(importlib.import_module(module), function)(raw_ocr, name)
    if output is None or not str(output).strip():
        raise RuntimeError("The research engine returned an empty report.")
    return str(output)

def save_report(data, filename="results/card_report.json"):
    path = Path(filename)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def main():
    while True:
        image_path = input("Card image path (or 'bye' to quit): ").strip().strip('"')
        if image_path.lower() == "bye":
            break
        try:
            card_result = identify_card(image_path)
            print_ocr_results(card_result)
            while True:
                engine = input("Research engine: openai, pydantic, crewai, langgraph (or 'bye' for another card): ").strip()
                if engine.lower() == "bye":
                    break
                try:
                    selected = normalize_engine(engine)
                    report = research_card(card_result["raw_ocr"], selected, image_path)
                    save_report({**card_result, "engine": selected, "report": report})
                    print(report)
                except (ValueError, ImportError) as error:
                    print(f"Could not research card: {error}")
        except Exception as error:
            print(f"Could not process card: {error}")
    print("Goodbye!")

if __name__ == "__main__":
    main()

