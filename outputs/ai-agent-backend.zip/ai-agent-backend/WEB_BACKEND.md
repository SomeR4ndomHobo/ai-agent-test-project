# AI Agent integration with Card Lab

The website's backend now runs directly from this project:

Card Lab → web_server.py → isolated api_worker.py process → app.py → your OCR / selected research engine.

Both the command-line app and website use app.identify_card and app.research_card. Changes to your engine files are used on the next job, without copying engines into a separate package. The existing .env is loaded before an engine is imported. The website never receives provider API keys.

## Run or deploy

1. Use Python 3.11 and install requirements.txt in a virtual environment. For web-layer tests only, install requirements-web.txt.
2. Keep your existing provider keys in .env locally, or configure OPENAI_API_KEY and (for LangGraph) TAVILY_API_KEY as deployment secrets.
3. Set BACKEND_ACCESS_TOKEN to a new random secret of at least 32 characters. Generate it with Python's secrets.token_urlsafe(48).
4. Set ALLOWED_ORIGINS to https://card-lab-research.workspace-838424.chatgpt.site. Add http://localhost:3000 only for local frontend development.
5. Run python web_server.py. It listens on PORT (default 8080). Deploy the included Dockerfile with HTTPS, one replica, and a persistent volume at /data writable by UID 10001. Set DATA_DIR=/data. OCR model initialization needs outbound downloads and sufficient memory; start with at least 4 GB and adjust to measured use.
6. In Card Lab, open “Backend not connected,” enter the HTTPS backend URL and BACKEND_ACCESS_TOKEN, and click Connect.
7. Upload a card, read its label, correct OCR text if needed, then select an engine and research the card.

The hosted website is at https://card-lab-research.workspace-838424.chatgpt.site. It cannot reach a Python process on this computer without a network-accessible backend. No Python hosting account has been selected, so this integration is implemented but not deployed online.

## API contract

All routes except /ready require Authorization: Bearer <BACKEND_ACCESS_TOKEN>. Origins are checked against the exact allowlist.

- GET /ready: hosting readiness probe.
- GET /health: authenticated connectivity check.
- POST /jobs/ocr with {"image":"base64 image"}.
- POST /jobs/research with {"engine":"openai","lines":[{"text":"label text"}]}.
- GET /jobs/<id>: returns queued/running/succeeded/failed plus result or error.

The engine names are openai, pydantic, crewai, and langgraph. Original CLI spellings psydantic and langraph remain accepted in app.py.

The service accepts JPG/PNG/WebP up to 10 MB and 25 megapixels, uses a bounded queue, and isolates each job to avoid collisions in OCR output paths. Reports persist under DATA_DIR. Uploads are deleted after processing. Anyone with the backend token can read these reports; this is a single-owner service.

## Verification

Run python -m unittest discover -s tests -v. API tests use a controlled worker and integration tests verify that the worker calls app.py and that app.py dispatches to each actual engine entrypoint. They do not call paid providers.

Live OCR/AI execution and the full Docker dependency installation still require a configured Python runtime. The existing system interpreter does not currently have the OCR or agent frameworks installed. The full Docker image has not been built here.

